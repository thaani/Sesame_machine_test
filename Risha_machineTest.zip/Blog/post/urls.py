from django.urls import path
from . import views
urlpatterns = [
    path('', views.post_home, name='post_home'),
    path('add_post/', views.add_post, name='add_post'),
    path('view_post/', views.view_post, name='view_post'),
]