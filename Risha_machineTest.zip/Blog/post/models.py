from django.db import models

# Create your models here.
class Posts(models.Model):
    heading = models.CharField(max_length=200)
    category = models.CharField(max_length=50)
    content = models.TextField()
