from django.shortcuts import render, redirect
from .models import Posts

# Create your views here.
def post_home(request):
    return render(request,"post/home.html")

def add_post(request):
    if request.method == "GET":
        return render(request,"post/add_post.html")
    else:
        heading = request.POST['heading']
        category = request.POST['category']
        content = request.POST['content']
        post = Posts(heading=heading, category=category, content=content)
        print(post)
        post.save()
        return redirect('/post/')

def view_post(request, template_name='post/view_post.html'):
    if request.GET.get('category'):
        featured_filter = request.GET.get('category')
        print(featured_filter)
        post = Posts.objects.filter(category=featured_filter)
    else:
        post = Posts.objects.all()

    context_dict = {'posts': post}
    return render(request, template_name, context_dict)
